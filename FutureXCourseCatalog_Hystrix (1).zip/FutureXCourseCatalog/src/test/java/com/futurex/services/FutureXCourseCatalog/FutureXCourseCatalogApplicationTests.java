package com.futurex.services.FutureXCourseCatalog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FutureXCourseCatalogApplicationTests {

	@Test
	void contextLoads() {
	}

}
