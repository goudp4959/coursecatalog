package com.futurex.services;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FuturexCourseAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
